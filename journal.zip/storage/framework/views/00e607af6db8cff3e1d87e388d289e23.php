<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>

    
 <?php $__env->slot('header', null, []); ?> 

<h4 class="italic text-base text-gren-700 dark:text-green-600">

<?php if(request()->query('view') ==='payouts'): ?>

<?php echo e(__('Money you have been paid by us will be shown here')); ?>


<?php else: ?>

<?php echo e(__('Money you have made from domain sales will be shown here')); ?>


<?php endif; ?>

</h4>


 <?php $__env->endSlot(); ?>

<div class="flex flex-col px-4">

<form method="GET" id="form" action="<?php echo e(route('dashboard.finance')); ?>" onchange="formFilter()">

<div class="flex flex-row justify-center items-center mt-6 mb-3">

<select class="inline-flex rounded-md shadow-sm" name="view">

<option disabled selected>--Filters--</option>

<option value="payouts">Payouts</option>

<option value="earnings">Earnings</option>

</select>

</div>

</form>

<div class="overflow-x-auto">

<div class="inline-block min-w-full py-2 sm:px-6 lg:px-8">

<div class="overflow-hidden">
    
<table class="min-w-full text-left text-sm font-light text-surface dark:text-white">

<thead class="border-b border-neutral-200 uppercase font-medium text-gray-800 dark:text-gray-100 dark:border-white/10">

<tr>

<th scope="col" class="px-6 py-4">Date</th>
<th scope="col" class="px-6 py-4">Description</th>
<th scope="col" class="px-6 py-4">Amount</th>
<th scope="col" class="px-6 py-4">Status</th>

</tr>

</thead>

<tbody>

<?php $__currentLoopData = $finance; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<tr class="border-b border-neutral-200 dark:border-white/10">

<td class="whitespace-nowrap px-6 py-4 font-medium"><?php echo e($result->created_at); ?></td>

<td class="whitespace-nowrap px-6 py-4">

    <?php if(request()->query('view') ==='earnings'): ?>

The sale of <?php echo e($result->description); ?>


<?php else: ?>

<?php echo e($result->description); ?>


<?php endif; ?>

</td>

<td class="whitespace-nowrap px-6 py-4">&#8358;<?php echo e(number_format($result->amount)); ?></td>

<td class="whitespace-nowrap px-6 py-4">

    <?php if($result->status ==="complete" || $result->status ==="paid"): ?>

<span class="text-green-800 bg-green-300 px-2 py-1 rounded-lg tiny-text"><?php echo e($result->status); ?></span>

<?php else: ?>

<span class="text-red-800 bg-red-300 px-2 py-1 rounded-lg tiny-text"><?php echo e($result->status); ?></span>

<?php endif; ?>

</td>

</tr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</tbody>
</table>
</div>
</div>
</div>
</div>

<div class="px-4 py-4">

    <?php echo e($finance->links()); ?>

    
    </div>

<script>

function formFilter() {

let form = document.getElementById('form');

form.submit();
}

</script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /home/myizupservices/journal/resources/views/dashboard/finance.blade.php ENDPATH**/ ?>