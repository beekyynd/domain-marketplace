<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="sec-hot">

    <div class="container mb-5 mt-3">
    
    <div class="row p-3">

        <?php if($findRef == 1): ?>
    
    <div class="alert alert-success mx-auto mt-5 text-center">

    This transaction <strong>#<?php echo e($reference); ?></strong> is already completed. Thank you!

    </div>

        <?php else: ?>

    <div class="alert alert-success mx-auto mt-5 text-center">
    
    <span>Thank you for your payment with Reference <strong>#<?php echo e($reference); ?></strong> . We will contact you using your payment email to begin transfer of ownership. Thank you!</span>
    
    </div>

    <?php endif; ?>
    
    </div>
    
    </div>
    
    </section>
     
<!-- Footer -->

<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/myizupservices/journal/resources/views/verifytx.blade.php ENDPATH**/ ?>